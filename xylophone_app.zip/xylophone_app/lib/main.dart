import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

void main() {
  runApp( xylophone());
}

class xylophone extends StatelessWidget {
  const xylophone({Key? key}) : super(key: key);


  playTone(int tone){
    final player = AudioCache();
    player.play('note$tone.wav',);
  }

  buildContainer (Color color, int tone){
    return Expanded(
      child: InkWell(
        child: Container(
          color: color,),
        onTap: () {
          playTone(tone);
        },
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
          body:
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,

              children: [
                buildContainer(Colors.red, 1),
                buildContainer(Colors.orange, 2),
                buildContainer(Colors.yellow, 3),
                buildContainer(Colors.green, 4),
                buildContainer(Colors.teal, 5),
                buildContainer(Colors.blue, 6),
                buildContainer(Colors.purple, 7),
              ],
            ),
          )
      ),
    );
  }
}

