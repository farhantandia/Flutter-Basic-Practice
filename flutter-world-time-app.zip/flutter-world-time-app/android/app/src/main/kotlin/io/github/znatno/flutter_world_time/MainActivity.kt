package io.github.znatno.flutter_world_time

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
