import 'package:http/http.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

class WorldTime {

  String location; 
  String time;    
  String flag;      
  String url;      
  bool isDaytime = false;  

  WorldTime({ this.location, this.flag, this.url });

  Future<void> getTime() async {

    try {
      // request
      Response response = await get(Uri.parse('https://timezone.abstractapi.com/v1/current_time?api_key=8b013486a7c8497ab2f210aabdd4594f&location=$url'));
      Map data = jsonDecode(response.body);

      // get properties from data
      String datetime = data['datetime'];
      // int offset = data['gmt_offset'];

      // DateTime obj
      DateTime now = DateTime.parse(datetime);

      // set time
      isDaytime = now.hour > 6 && now.hour < 19;
      time = DateFormat.jm().format(now);
    }
    catch (e) {
      print('caught error: $e');
      time = 'could not get time data';
    }

  }

}