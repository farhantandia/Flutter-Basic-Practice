class Question {
  String? questionText;
  bool? questionAnswer;

  Question(String s, bool a){
    questionText = s;
    questionAnswer = a;
  }
}