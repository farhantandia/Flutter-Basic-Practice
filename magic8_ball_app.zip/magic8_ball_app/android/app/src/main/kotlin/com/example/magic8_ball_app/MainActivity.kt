package com.example.magic8_ball_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
